#!/bin/bash
#Script de Backup
echo "Inicializando el sistema de backups..."
#1 Definir la funcion de ayuda  (-help)
mostrar_ayuda(){
   echo "Uso: $0 [origen] [destino]"
   echo ""
   echo "Argumentos: "
   echo "origen   Ruta del directorio al que se quiere hacer copia "
   echo " destino   Ruta de la particion donde se guardará el Backup"
   echo ""
   echo "Opciones: "
   echo "  -help   Muestra esta  guia de uso"
   exit 0
}

#Si el usuario pide ayuda o no pone argumentos, mostras ayuda

if [[ "$1" == "-help" || -z "$1" || -z "$2" ]];then 
   mostrar_ayuda 
fi

#Capturar los argumentos de origen y destino 

ORIGEN="$1"
DESTINO="$2"

# Validar que origen y destino estén disponibles

if [ ! -d "$ORIGEN" ]; then
echo"Error : El directorio de origen ($ORIGEN) no existe o no está idsponible "
exit 1
fi

if [ ! -d "$DESTINO" ]; then
echo"Error: El directorio de destino ($DESTINO) no existe o no está montado."


#Obtener la fecha en formato ANSI (YYYYMMDD)

FECHA=$(date +%Y%m%d)

#Extraer el nombre limpio de la carpeta de origen

NOMBRE_BASE=$(basename "$ORIGEN")

#Definir el nombre final del archivo comprimido según el formato exigido

ARCHIVO_SALIDA="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"


echo"procesando esta copia de seguridad..."
echo"Origen: $ORIGEN"
echo "Destino: $ARCHIVO_SALIDA"

#Ejecutar el empaquetado y  la compresion en formato tar.gz
tar -czf "ARCHIVO_SALIDA" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

#Verificar que el comando tar terminó con exito
if[ $? -eq 0]; then
echo "Backup completado con exito"
else 

echo "error: ocurrió un problema al empaquetar los archivos "
exit 1
fi
 

