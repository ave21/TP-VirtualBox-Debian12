history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
su
cat /etc/debian_version
cat /etc/apt/sources.list
ls /etc/atp/sources.list.d/
ls /etc/apt/sources.list.d/
apt-get update
ping -c 4 192.168.0.1
ping -c 4 1.1.1.1
getent hosts deb.debian.org
ip -br address
shutdown -h now
shutdown -h now
su
cat /etc/apt/sources.list
echo "deb https://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb https://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list
cat etc/apt/sources.list
cat /etc/apt/sources.list
apt-get update
apt-get upgrade
apt-get full-upgrade
cat /etc/debian_version
cat /etc/os-release
reboot
su
dkgp -l | grep openssh-server
dpkg -l | grep openssh-server
systemctl status ssh
apt-get install openssh-server
systemctl status ssh
shutdown -h
shutdown -h now 
mkdir -p/root/.ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh 
ls -ld /root/.ssh
ssh-keygen -t ed25519
cat /root/.ssh/id_ed25519.pub >> /root/.ssh/
cat /root/.ssh/id_ed25519.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 //root/.ssh/authorized_keys
chmod 600 //root/.ssh/id_ed25519
chmod 600 //root/.ssh/id_ed25519.pub
ls -la /root/.ssh
nano /etc/ssh/sshd_config
apt-get install nano
nano /ssh/sshd_congig
dpkg -l openssh-server
ls -l /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
ssh -t
systemctl restart ssh
sshd -t
 sed -i 's/ggginclude/Include/g' /etc/ssh/sshd_config
systemctl daemon-reload
systemctl restart ssh

systemctl daemon-reload
systemctl restart ssh
systemctl status ssh
ssh -T | -E 'permitrootlogin | pubkey authentication'
ssh -T | grep -E 'permitrootlogin | pubkey authentication'
sshd -T | grep -E 'permitrootlogin | pubkey authentication'
sshd -T | grep -i pubkey
ssh keygen -p -f /root/.ssh/id_ed25519
ssh-keygen -p -f /root/.ssh/id_ed25519
cat 7root/.ssh/id_ed25519
cat /root/.ssh/id_ed25519
hostname -I
scp /root/.ssh/id_ed25519 walter@192.168.0.100:/Users/walter/Desktop/id_ed25519.txt
ssh-keygen -t rsa -b 2048 -f /root/.ssh/id_rsa -N""
ssh-keygen -t rsa -b 2048 -f /root/.ssh/id_rsa 
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/id_rsa
nano /etc/ssh/sshd_config
systemctl restart ssh
shutdown -h now
su
apt update
apt-get install apache2 php libapache2-mod-php -y
systemctl status apache2
php -v
ls -l /root/index.php /root/logo.png
ls -l /root /index.php /root/logo.png
cp /root/index.php /var/www/html/
ls -la /root
cd
cd.
cd..
cd...
find / -name "index.php" 2>/dev/null
find / -name "logo.png" 2>/dev/null
exit
ls -ld /alumnos
ls /alumnos
ls /home/alumnos
ls -la
cd /home /alumnos
cd /home/alumnos
exit
su
cd /home/alumnos
ls -ld /alumnos
ls -ls /home
ls -la /home
ls -ld /home/alumnos
pwd
ls -la
find mnt
findmnt
ls -ls /home
ls -la /home
ls -lb /home
stat /home/alumnos
stat /home/alumnosls -lb /home
ls -lb /home
cd /home/compartido
pwd
ls -la
find /home/compartido -type f \( -name "index.php" -o -name "logo.png" \) 2>/dev/null
find /home/compartido -maxdepth 3 -print
ls -la /home/compartido/dir1
cd /home/compartido
ls -l hola arch1 arch2
find / type f \( -iname "index.php" -o -iname"logo.png" \) 2>/dev/null
shutdown -h now
ls -ld /compartido
pwd
sudo
su
cd...
cd..
cd
cd.
cd
pwd
ls -la
cd /home
ls -la
find / -name "index.php" 2>/dev/null
ls -la /home
ls -ld /compartido
su
ls -la /media
shutdown -h now
shutdown -h now
ls -la /media
sudo modeprobe vboxadd
sudo modeprobe vboxvfx
sudo apt update
apt list --upgradable
apt install linux-compiler-gcc-12-x86
apt install linux-headers-amd64
apt update
sudo atp update
sudo apt update
sudo apt install build-essential dkms linux-headers-$(uname -r)
sudo apt autoremove
power off
sudo poweroff
sudo mkdir -p /mnt/cdrom
sudo mount /dev/sr0 /mnt/cdrom
sudo sh /mnt/cdrom/VBoxLinuxAdditions.run
sudo usermod -aG vboxsf$USER
sudo usermod -aG vboxsf $USER
sudo reboot
ls -la /media
cd /media/sf_Compartida
cd /media/sf_compartida
cd /media/sf_Desktop
ls 
cd
reboot 
ls -la /media
cd /media/sf_Compartida
ls
cd
poweroff
sudo apt update
apt install -y apache2 php libapache2-mod-php
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano/etc/apache2/apache2.conf
sudo nano /etc/apache2/apache2.conf
sudo nano /etc/apache2/mods-enabled/dir.conf
sudo chmod 755 /root
sudo chmod 644 /root/index.php
sudo chmod 644 /root/logo.png
sudo apache2ctl configtest
sudo nano /etc/apache2/apache2.conf
sudo apache2ctl configtest
sudo apache2
sudo systemctl status apache2
sudo cp /media/sf_Compartida/index.php /root/
sudo cp /media/sf_Compartida/db.sql /root/
sudo chmod 644 /root/index.php
ls -la /root/
sudo wget -o /root/logo.png https://debian.org
sudo chmod 644 /root/logo.png
ls -la /root/
sudo systemctl start apache2 
sudo systemctl status apache2 
sudo ufw disable
sudo wget -o /root/logo.png https://debian.org && sudo chmod 644 /root/logo.png
sudo nano /etc/apache2/ports.conf
sudo nano /etc/apache2/ports.conf
sudo systemctl restart apache2  
sudo curl -I http://localhost
sudo tail -n 20 /var/log/apache2/error.log
sudo apt update
sudo apt install -y mariadb-server php-mysql
sudo systemctl restart apache2
sudo head n-20 /root/db.sql
sudo mariadb
sudo mariadb ingenieria < /root/db.sql
sudo mariadb ingenieria < /root/db.sql
sudo mariadb -e "DROP DATSBASE ingenieria;"
sudo mariadb -e "DROP DATABASE ingenieria;"
sudo mariadb < /root/db.sql
sudo mariadb -e "USE ingenieria; SHOW TABLES;"
sudo chown -R www-data:www-data /root
sudo chmod 755 /root
sudo chmod 644 /root/index.php /root/logo.png
sudo systemctl enable apache2
sudo systemctl restart apache2
sudo nano /etc/apache2/sites-available/000-default.conf
sudo rm -f /var/www/html/index.html
sudo ln -s /root/index.php /var/www/html/index.php
sudo ln -s /root/logo.png /var/www/html/logo.png
sudo chown -R root:root /root
sudo chmod 755 /root
sudo chmod 644 /root/index.php /root/logo.png
sudo systemctl restart apache2
shutdwn -h now
shutdown -h now
sudo rm -f /var/www/html/index.php
sudo rm -f /var/www/html/logo.png
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano /etc/apache2/apache2.conf
sudo chmod 755 /root
sudo chmod 755 /root/index.php /root/logo.png /root/db.sql
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo nano /etc/network/interfaces
sudo reboot
http://192.168.0.200
curl -I http://192.168.0.200
sudo /etc/network/interfaces
sudo nano /etc/network/interfaces
sudo systemctl restart networking
sudo ifup enp0s3
ip a show enp0s3
sudo systemctl restart apache2
sudo systemctl status apache2
curl -I http://192.168.0.200
sudo nano /etc/apache2/ports.conf
curl -I http://192.168.0.200
sudo systemctl edit apache2  
sudo systemctl daemon-reload
sudo systemctl restart apache2
curl -I http://192.168.0.200
shutdown -h now
lsblk
sudo fdisk /dev/sdc
sudo mkfs.ext4 /dev/sdc1
sudo mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
mkdir -p /backup_dir
sudo nano /etc/fstab
sudo mount -a 
sudo cp /root/index.php /www_dir/
sudo cp /root/logo.png /www_dir/
sudo chmod -R 755 /www_dir
sudo nano /etc/apache2/sites-available/000-default.conf
sudo nano /etc/apache2/apache2.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo cat /proc/partitions | sudo tee /opt/particion
shutdown -h now
nano /etc/fstab
sudo blkid | grep sdc1 | awk '{print $2}' | sed 's/"//g' | awk '{print $1 " /www_dir ext4 defaults, errors=remount -ro 0 2"}' | sudo tee -a /etc/fstab
sudo blkid | grep sdc2 | awk '{print $2}' | sed 's/"//g' | awk '{print $1 " /backup_dir ext4 defaults, errors=remount -ro 0 2"}' | sudo tee -a /etc/fstab
sudo nano /etc/fstab
sudo unmount /www_dir /backup_dir
sudo umount /www_dir /backup_dir
sudo mount -a
sudo nano /etc/fstab
sudo umount /www_dir /backup_dir
sudo mount -a
sudo nano  /etc/fstab
sudo unmount /www_dir /backup_dir
sudo umount /www_dir /backup_dir
sudo mount -a 
sudo nano /etc/fstab
sudo mount -a
systemctl daemon-reload
sudo mount -a 
df -m
sudo mkdir -p /opt/scripts
sudo nano /opt/scripts/backup_full.sh
sudo chmod +x /opt/scripts/backup_full.sh
sudo /opt/scripts/backup_full.sh
sudo nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help 
sudo nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help 
sudo nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help 
sudo nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help 
shutdown -h now
